> 本文件夹为 es-dev-standard cli 存放配置文件的文件夹勿动

.editorconfig `编辑配置`  
.eslintrc.config.js `eslint配置`   
.prettierrc `prettier配置`   
commitlint.config.js `commitlint配置`  
vue.eslintrc.config.js `vue项目 初始化eslint配置`  
