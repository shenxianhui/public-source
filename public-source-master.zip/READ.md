## 配置文件存放仓库

#### 目前已存放项目配置文件列表如下

1. es-dev-standard 前端开发规范 cli  
    存放目录： es-dev-standard